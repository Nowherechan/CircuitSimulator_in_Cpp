/**
  * baselogicgate.cpp
  * author@王梦泽&尤曼绮
  * tester@刘睿尧
  * function:
  *     an abstract logic gate
  * bug:(when one bug was fixed, marked it with '~')
  *     null
  * TODO:(when one was completed, marked it with '~')
  *     null
  */
#include "baselogicgate.h"
#include"andlogicgate.h"
#include"orlogicgate.h"
#include"nonlogicgate.h"
#include<QPainter>

baselogicgate::baselogicgate()
{
}
///////////////
// baselogicgate *andlog = new andLogicGate;
 //baselogicgate *orlog = new orLogicGate;
 //baselogicgate *nonlog = new nonLogicGate;
///////////////////////////////////////
//void baselogicgate::getPaint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget){
//    int getPaint(int paintNum);

//   switch(paintNum)
//{



//   }
//}
